## usethis namespace: start
#' @useDynLib gammaFrailty, .registration = TRUE
## usethis namespace: end
NULL
## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
## usethis namespace: start
#' @import RcppEigen
## usethis namespace: end
NULL
## usethis namespace: start
#' @importFrom stats rbinom rnorm rpois
## usethis namespace: end
NULL

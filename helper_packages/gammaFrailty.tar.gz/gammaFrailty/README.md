
<!-- README.md is generated from README.Rmd. Please edit that file -->

# gammaFrailty

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://lifecycle.r-lib.org/articles/stages.html#experimental)
[![CRAN
status](https://www.r-pkg.org/badges/version/gammaFrailty)](https://CRAN.R-project.org/package=gammaFrailty)
<!-- badges: end -->

The gammaFrailty package allows the estimation of serially correlated
Gamma-frailty models for count data as described in [Henderson &
Shimakura
(2003)](https://academic.oup.com/biomet/article/90/2/355/241234).

## Installation

...

## Example

Simple illustrative setting taken from [Henderson & Shimakura
(2003)](https://academic.oup.com/biomet/article/90/2/355/241234)

``` r
library(gammaFrailty)
seed <- 123
set.seed(seed)

# Setup data generating process
## Set dimensions
p <- 12; q <- 8; m <- 2; n <- 250

## Set parameters
xi <- 2/q; rho <- .6;
int <- rep(log(4), p)
b <- rep(0, m) 

## True parameter vector (and its reparameterisation)
theta <- c(xi, rho, b, int)
repar_theta <- partorepar(theta)

## Generate binary covariates
X <- matrix(rbinom(m*n, 1, .5), n, m)

## Generate data
data <- generate_data(
    INTERCEPT = int,
    BETA = b,
    X = X,
    Q = q,
    RHO = rho,
    SEED = seed,
    STRUCT = 'COMPOUND'
)


# Estimation
## Initialisation vector
par_init <- repar_theta + runif(length(repar_theta), -1, 1)

fit <- fit_gammaFrailty2(
    DATA_LIST = list('DATA' = data, 'X' = X),
    METHOD = 'ucminf',
    CPP_CONTROL = list(),
    VERBOSEFLAG= 0,
    INIT = par_init,
    ITERATIONS_SUBSET = NULL,
    STRUCT = 'COMPOUND'
)
#> 1. Initialising at init vector.
#> 2. Optimising with ucminf...
#> 3. Done! (0.55 secs)

mean((repartopar(fit$theta)-theta)^2)
#> [1] 0.001013602
mean((repartopar(par_init)-theta)^2)
#> [1] 0.1994173
```

``` r

rfit <- fit_gammaFrailty2(
    DATA_LIST = list('DATA' = data, 'X' = X),
    METHOD = 'randomized',
    CPP_CONTROL = list(PROB=.5),
    VERBOSEFLAG= 0,
    INIT = par_init,
    ITERATIONS_SUBSET = NULL,
    STRUCT = 'COMPOUND'
)
#> 1. Initialising at init vector.
#> 2. Optimising with ranodmized ucminf...
#> 3. Done! (0.18 secs)

mean((repartopar(rfit$theta)-theta)^2)
#> [1] 0.003262659
mean((repartopar(par_init)-theta)^2)
#> [1] 0.1994173
```

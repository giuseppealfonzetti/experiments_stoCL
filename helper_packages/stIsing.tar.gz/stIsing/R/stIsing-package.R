## usethis namespace: start
#' @useDynLib stIsing, .registration = TRUE
## usethis namespace: end
NULL
## usethis namespace: start
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
## usethis namespace: start
#' @import RcppEigen
## usethis namespace: end
NULL
## usethis namespace: start
#' @import RcppClock
## usethis namespace: end
NULL
